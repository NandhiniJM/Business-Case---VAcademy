package com.VAcademy.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VAcademy.Entity.Reply;

public interface ReplyDAO  extends JpaRepository<Reply,Integer> {

    Reply findReplyByRepliedbyAndQidAndTimestamp(String user, Integer qid, String timestamp);
}
