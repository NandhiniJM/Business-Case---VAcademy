package com.VAcademy.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VAcademy.Entity.Admin;


public interface AdminDAO extends JpaRepository<Admin,Integer>
{
    Admin findAdminByUsername(String username);
    Boolean existsAdminByUsername(String username);
}