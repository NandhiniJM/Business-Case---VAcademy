package com.VAcademy.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VAcademy.Entity.User;

public interface UserDAO extends JpaRepository<User,Integer>
{
    User findUserByUserid(Integer id);
    boolean existsUserByUsername(String name);
    boolean existsUserByEmail(String email);
    boolean existsUserByMobile(String mobile);
    User findUserByUsername(String username);
}
