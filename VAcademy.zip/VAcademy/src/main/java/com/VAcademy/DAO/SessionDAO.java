package com.VAcademy.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VAcademy.Entity.Session;

public interface SessionDAO extends JpaRepository<Session,Integer>
{
    Session findSessionBySessionid(Integer id);
    Boolean existsSessionBySessionid(Integer id);
    Session findSessionByUsernameAndTypeAndIntimeAndOutTimeEquals(String username,String type, String in_time, String outTime);
}
