package com.VAcademy.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VAcademy.Entity.Question;

public interface QuestionDAO extends JpaRepository<Question,Integer> {

    Question findQuestionByPostedbyAndTimestampAndTopic(String user,String timestamp, String topic);
}
