package com.VAcademy.Controller;

import com.VAcademy.DAO.*;
import com.VAcademy.Entity.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController

public class VAcademyController
{
    @Autowired
    private UserDAO userDAO;

    @Autowired
    private CourseDAO courseDAO;

    @Autowired
    private AdminDAO adminDAO;

    @Autowired
    private InstructorDAO instructorDAO;

    @Autowired
    private SessionDAO sessionDAO;

    @Autowired
    private QuestionDAO questionDAO;

    @Autowired
    private ReplyDAO replyDAO;

    //Admin
    @GetMapping(value = "/admin/all-admins")
    public List<Admin> getAllAdmin(){
        return adminDAO.findAll();
    }

    @GetMapping(value = "/admin/get-admin/{username}")
    public Admin getAdmin(@PathVariable String username)
    {
        return adminDAO.findAdminByUsername(username);
    }

    @GetMapping(value = "/admin/user/all-users")
    public List<User> getAllUsers()
    {
        return userDAO.findAll();
    }

    @GetMapping(value = "/admin/instructor/all-instructors")
    public List<Instructor> getAllInstructors()
    {
        return instructorDAO.findAll();
    }

    @GetMapping(value = "/admin/session/all-sessions")
    public List<Session> getAllSessions()
    {
        return sessionDAO.findAll();
    }

    @PostMapping(value = "/admin/add-admin")
    public String addAdmin(@RequestBody Admin admin)
    {
        String admin_username =  admin.getUsername();
        if(adminDAO.existsAdminByUsername(admin_username)) {
            return "Admin Username already exists";
        }
        else
        {
            adminDAO.save(admin);
            return admin_username + "Account added Successfully";
        }
    }

        //Courses
    @GetMapping(value = "/common/all-courses")
    public List<Course> getAllCourses()
    {
        return courseDAO.findAll();
    }

    @PostMapping(value = "/course/get-course")
    public Course getCourseByCourseBody(@RequestBody Course course)
    {
        String name = course.getCoursename();
        String author = course.getAuthor();
        return courseDAO.findCourseByCoursenameAndAuthor(name,author);
    }

    @GetMapping(value = "/course/course-id={id}")
    public Course getCourseById(@PathVariable Integer id)
    {
        return courseDAO.findCourseByCourseid(id);
    }

    @PostMapping(value = "/course/add-course")
    public String addCourse(@RequestBody Course course)
    {
        try {
            String course_code = course.getCoursecode();
            String course_name = course.getCoursename();
            for (Course courses : courseDAO.findAll()) {
                if (courses.getCoursecode().equals(course_code)) {
                    return "Course Code already exists";
                } else if (courses.getCoursename().equals(course_name)) {
                    return "Course Name already exists";
                }
            }
            courseDAO.save(course);
            Course code_course = courseDAO.findCourseByCoursecode(course.getCoursecode());
            code_course.setCoursecode(code_course.getCoursecode().concat(Integer.toString(code_course.getCourseid())));
            courseDAO.save(code_course);
            return course_name + " added Successfully";
        }
        catch (Exception e)
        {
            return "Error! Course not added!";
        }
    }

    @PostMapping(value = "course/update/details")
    public Course updateCourseDetails(@RequestBody Course course)
    {
        Course edit_course = courseDAO.findCourseByCoursecode(course.getCoursecode());
        edit_course.setCoursename(course.getCoursename());
        edit_course.setDescrp(course.getDescrp());
        edit_course.setAuthor(course.getAuthor());
        edit_course.setTags(course.getTags());
        edit_course.setTest(course.getTest());
        edit_course.setChapters(course.getChapters());
        edit_course.setVideos(course.getVideos());
        edit_course.setImage(course.getImage());
        edit_course.setPrice(course.getPrice());
        edit_course.setUpdated_on(course.getUpdated_on());
        try {
            courseDAO.save(edit_course);
            return courseDAO.findCourseByCoursecode(course.getCoursecode());
        }
        catch (Exception e) {
            return null;
        }
    }

    @GetMapping(value = "course/update/enrolls/{id}")
    public String updateEnrolls(@PathVariable Integer id)
    {
        Course edit_course = courseDAO.findCourseByCourseid(id);
        try {
            int x = Integer.parseInt(edit_course.getEnrolls()) + 1;
            edit_course.setEnrolls(Integer.toString(x));
            courseDAO.save(edit_course);
            return "Enrolls updated successfully";
        }
        catch (Exception e) {
            return "Enrolls not updated!";
        }
    }

    //User
    @GetMapping(value = "/user/get-user/{username}")
    public User getUser(@PathVariable String username)
    {
        return userDAO.findUserByUsername(username);
    }

    @PostMapping(value = "/common/add-user")
    public String createUser(@RequestBody User new_user)
    {
        try {
            String new_user_name = new_user.getUsername();
            String new_user_email = new_user.getEmail();
            String new_user_mobile = new_user.getMobile();
            if (userDAO.existsUserByUsername(new_user_name)) {
                return "Username already exists";
            } else if (userDAO.existsUserByEmail(new_user_email)) {
                return "Email already exists";
            } else if (userDAO.existsUserByMobile(new_user_mobile)) {
                return "Mobile already exists";
            } else {
                userDAO.save(new_user);
                return new_user_name + " Account added Successfully";
            }
        }
        catch (Exception e)
        {
            return "Invalid Details! Please provide correct details";
        }
    }

    @PostMapping(value = "/user/update/payment")
    public User updatePayment(@RequestBody User user)
    {
        User edit_user = userDAO.findUserByUserid(user.getUserid());
        edit_user.setEnrolled_courses(user.getEnrolled_courses());
        edit_user.setPayment_details(user.getPayment_details());
        userDAO.save(edit_user);
        return userDAO.findUserByUserid(user.getUserid());
    }

    @PostMapping(value = "/user/update/course-complete")
    public User updateCourseComplete(@RequestBody User user)
    {
        User edit_user = userDAO.findUserByUserid(user.getUserid());
        edit_user.setCourses_completed(user.getCourses_completed());
        edit_user.setActive_courses(user.getActive_courses());
        userDAO.save(edit_user);
        return userDAO.findUserByUserid(user.getUserid());
    }

    @PostMapping(value = "/user/update/password")
    public User updatePassword(@RequestBody User user)
    {
        User edit_user = userDAO.findUserByUserid(user.getUserid());
        edit_user.setPassword(user.getPassword());
        userDAO.save(edit_user);
        return userDAO.findUserByUserid(user.getUserid());
    }

    @PostMapping(value = "/user/update/interest")
    public User updateSuggesstion(@RequestBody User user)
    {
        User edit_user = userDAO.findUserByUserid(user.getUserid());
        edit_user.setInterest(user.getInterest());
        userDAO.save(edit_user);
        return userDAO.findUserByUserid(user.getUserid());
    }

    @PostMapping(value = "/user/update/profile")
    public User updateProfile(@RequestBody User user)
    {
        User edit_user = userDAO.findUserByUserid(user.getUserid());
        edit_user.setFullname(user.getFullname());
        edit_user.setUsername(user.getUsername());
        edit_user.setEmail(user.getEmail());
        edit_user.setMobile(user.getMobile());
        edit_user.setParent_mobile(user.getParent_mobile());
        userDAO.save(edit_user);
        return userDAO.findUserByUserid(user.getUserid());
    }

    //Instructor
    @GetMapping(value = "/instructor/{username}")
    public Instructor getInstructor(@PathVariable String username)
    {
        return instructorDAO.findInstructorByUsername(username);
    }

    @PostMapping(value = "/common/add-instructor")
    public String addInstructor(@RequestBody Instructor instructor)
    {
        String instructor_username = instructor.getUsername();
        String instructor_email =  instructor.getEmail();
        if(instructorDAO.existsInstructorByUsername(instructor_username))
        {
            return "Instructor Username already exists";
        }
        else if(instructorDAO.existsInstructorByEmail(instructor_email))
        {
            return "Instructor Email already exists";
        }
        else {
            instructorDAO.save(instructor);
            return instructor_username + " Account added Successfully";
        }
    }

    @PostMapping(value = "/instructor/update/profile")
    public Instructor updateInstructorProfile(@RequestBody Instructor instructor)
    {
        Instructor edit_instructor = instructorDAO.findInstructorByUsername(instructor.getUsername());
        edit_instructor.setFullname(instructor.getFullname());
        edit_instructor.setUsername(instructor.getUsername());
        edit_instructor.setEmail(instructor.getEmail());
        edit_instructor.setMobile(instructor.getMobile());
        edit_instructor.setQualification(instructor.getQualification());
        instructorDAO.save(edit_instructor);
        return instructorDAO.findInstructorByUsername(instructor.getUsername());
    }

    @PostMapping(value = "/instructor/update/password")
    public Instructor updateInstructorPassword(@RequestBody Instructor instructor)
    {
        Instructor edit_instructor = instructorDAO.findInstructorByUsername(instructor.getUsername());
        edit_instructor.setPassword(instructor.getPassword());
        instructorDAO.save(edit_instructor);
        return instructorDAO.findInstructorByUsername(instructor.getUsername());
    }

    @GetMapping(value = "/instructor//update/course/{username}/{course_code}/{id}")
    public Instructor updateInstructorCourse(@PathVariable String username, @PathVariable String course_code, @PathVariable Integer id)
    {
        try {
            Instructor edit_instructor = instructorDAO.findInstructorByUsername(username);
            edit_instructor.setCourses(edit_instructor.getCourses().concat(course_code + "#" + id + ","));
            instructorDAO.save(edit_instructor);
            return instructorDAO.findInstructorByUsername(username);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    //Session
    @GetMapping(value = "/session/{id}")
    public Session getSession(@PathVariable Integer id)
    {
        return sessionDAO.findSessionBySessionid(id);
    }

    @PostMapping(value = "/session/add-session")
    public Session addSession(@RequestBody Session session)
    {
        try {
            sessionDAO.save(session);
            return sessionDAO.findSessionByUsernameAndTypeAndIntimeAndOutTimeEquals(session.getUsername()
                    , session.getType(), session.getIntime(), "active");
        }
        catch (Exception e)
        {
            return null;
        }
    }

    @PostMapping(value = "/session/update")
    public String updateSession(@RequestBody Session session)
    {
        try {
            if (sessionDAO.existsSessionBySessionid(session.getSessionid())) {
                Session current_session = sessionDAO.findSessionBySessionid(session.getSessionid());
                String x = session.getOutTime();
                current_session.setOutTime(x);
                sessionDAO.save(current_session);
                return "Session Updated Successfully";
            } else {
                return "Session Not Found";
            }
        }
        catch (Exception e)
        {
            return "Error! Session not updated";
        }
    }

    //Question
    @GetMapping(value = "/forum/all-questions")
    public List<Question> getAllQuestions()
    {
        return questionDAO.findAll();
    }

    @PostMapping(value = "/forum/post/question")
    public Question addQuestion(@RequestBody Question question)
    {
        questionDAO.save(question);
        return questionDAO.findQuestionByPostedbyAndTimestampAndTopic(question.getPostedby(),question.getTimestamp(),question.getTopic());
    }

    //Reply
    @GetMapping(value = "/forum/all-replies")
    public List<Reply> getAllReplies()
    {
        return replyDAO.findAll();
    }

    @PostMapping(value = "/forum/post/reply")
    public Reply addReply(@RequestBody Reply reply)
    {
        replyDAO.save(reply);
        return replyDAO.findReplyByRepliedbyAndQidAndTimestamp(reply.getRepliedby(),reply.getQid(),reply.getTimestamp());
    }
}