package com.VAcademy.Entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity( name = "Session")
public class Session
{
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "SESSION_ID")
    private Integer sessionid;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "USER_NAME")
    private String username;
    @Column(name = "LOG_DATE")
    private String log_date;
    @Column(name = "IN_TIME")
    private String intime;
    @Column(name = "OUT_TIME")
    private String outTime;

    public Session() {
    }

    public Session(String type, String username, String log_date, String intime, String outTime) {
        this.type = type;
        this.username = username;
        this.log_date = log_date;
        this.intime = intime;
        this.outTime = outTime;
    }

    public Integer getSessionid() {
        return sessionid;
    }

    public void setSessionid(Integer sessionid) {
        this.sessionid = sessionid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLog_date() {
        return log_date;
    }

    public void setLog_date(String log_date) {
        this.log_date = log_date;
    }

    public String getIntime() {
        return intime;
    }

    public void setIntime(String in_time) {
        this.intime = in_time;
    }

    public String getOutTime() {
        return outTime;
    }

    public void setOutTime(String out_time) {
        this.outTime = out_time;
    }
}

